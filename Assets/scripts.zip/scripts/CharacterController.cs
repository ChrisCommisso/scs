﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;

namespace Assets.scripts
{
    public class CharacterController : MonoBehaviour
    {
        
        public GameObject genericCharacter;
        Move player1current;
        Move player2current;
        public Vector3 Velocity;
        public GameObject player1Object;
        public Character player1Character;
        public GameObject player2Object;
        public Character player2Character;
        bool isLeft(GameObject character, bool isPlayer2) 
        {
            if (isPlayer2)
            {
                if (character.transform.position.x >= player1Object.transform.position.x)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            else 
            {
                if (character.transform.position.x >= player2Object.transform.position.x)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
        }
        bool tryInput(string[] input, bool isPlayer2) 
        {

            Dictionary<string, int> playerinputs = InputTracker.player1;
            GameObject playerObject = player1Object;
            if (isPlayer2) 
            {
                playerObject = player2Object;
                playerinputs = InputTracker.player2;
            }
            int inputIndex = 0;
            foreach (string buttonid in input)
            {
                string[] combinedInputs = new string[0];
                List<string> altIDs = new List<string>();
                if (buttonid.Contains("+")) 
                {
                    combinedInputs = buttonid.Split('+');
                }
                string id = buttonid;
                if (isLeft(player2Object, isPlayer2)) 
                {
                    id = InputTracker.leftRightConversion(id);
                }
                
                
                int framesSinceinput = input.Length-inputIndex*6;
                if (playerinputs[id] < framesSinceinput )
                {
                    foreach (var inputs in combinedInputs)
                    {
                        if (playerinputs[id] - playerinputs[inputs] >= 3 && playerinputs[id] - playerinputs[inputs] < 0) 
                        {
                            return false;
                        }
                    }
                    return false;
                }
                
                inputIndex++;
            }
            return true;
        }
        void onAnimate(InputTracker tracker) 
        {
            if (player1current.frameData.hitstopFrames > 0)
            {
                player1current.frameData.hitstopFrames--;
            }
            else if (player1current.currentFrame == player1current.frameData.animLength)
            {
                player1current = player1Character.Animations[player1current.frameData.naturalEndAnim].Copy();
            }
            else
            {
                foreach (string cancelData in player1current.frameData.canCancelTo)
                {
                    bool requireHit = cancelData[0] == '~';
                    string data = cancelData;
                    if (requireHit)
                    {
                        data = cancelData.Substring(1);
                    }

                    int cancelMinFrame = 0;
                    string anim = "";
                    if (data.Contains('-'))
                    {
                        string[] cData = data.Split('-');
                        anim = cData[0];
                        int.TryParse(cData[1], out cancelMinFrame);
                    }
                    if (player1current.currentFrame >= player1current.frameData.animLength && tryInput(player1Character.Animations[anim].frameData.input, false))
                    {
                        player1current = player1Character.Animations[anim].Copy();
                        break;
                    }

                }
                player1Object.gameObject.GetComponent<SpriteRenderer>().sprite = player1current.frames[player2current.currentFrame];

            }
            if (player2current.frameData.hitstopFrames > 0)
            {
                player2current.frameData.hitstopFrames--;
            }
            else if (player2current.currentFrame == player2current.frameData.animLength) 
            {
                player2current = player2Character.Animations[player2current.frameData.naturalEndAnim].Copy();
            }
            else
            {
                foreach (string cancelData in player2current.frameData.canCancelTo)
                {
                    bool requireHit = cancelData[0] == '~';
                    string data = cancelData;
                    if (requireHit)
                    {
                        data = cancelData.Substring(1);
                    }

                    int cancelMinFrame = 0;
                    string anim = "";
                    if (data.Contains('-'))
                    {
                        string[] cData = data.Split('-');
                        anim = cData[0];
                        int.TryParse(cData[1], out cancelMinFrame);
                    }
                    if (player2current.currentFrame>=player2current.frameData.animLength&&tryInput(player2Character.Animations[anim].frameData.input, false)) 
                    {
                        player2current = player2Character.Animations[anim].Copy();
                        break;
                    }
                }
                player2Object.gameObject.GetComponent<SpriteRenderer>().sprite = player2current.frames[player2current.currentFrame];
            }
        }
        void onResolve() 
        {
            #region resolve p1&p2 hit
            Vector3 player1Position = player1Object.transform.position;
            Vector3 player2Position = player2Object.transform.position;
            Rectangle[] player1Hurtboxes = player1current.frameData.hurtBoxes[player1current.currentFrame].ToArray();
            Rectangle[] player2Hurtboxes = player2current.frameData.hurtBoxes[player1current.currentFrame].ToArray();
            List<HitboxGroup> player1Hitboxes = new List<HitboxGroup>();
            List<HitboxGroup> player2Hitboxes = new List<HitboxGroup>();
            for (int i = 0; i < player1Hurtboxes.Length; i++)
            {
                player1Hurtboxes[i] = new Rectangle((int)(player1Hurtboxes[i].X * player1Object.transform.localScale.x), (int)(player1Hurtboxes[i].Y * player1Object.transform.localScale.y),(int)(player1Hurtboxes[i].Width * player1Object.transform.localScale.x), (int)(player1Hurtboxes[i].Height * player1Object.transform.localScale.y));
            }
            for (int i = 0; i < player2Hurtboxes.Length; i++)
            {
                player2Hurtboxes[i] = new Rectangle((int)(player2Hurtboxes[i].X * player2Object.transform.localScale.x), (int)(player2Hurtboxes[i].Y * player2Object.transform.localScale.y), (int)(player2Hurtboxes[i].Width * player2Object.transform.localScale.x), (int)(player2Hurtboxes[i].Height * player2Object.transform.localScale.y));
            }
            foreach (var hitboxGroup in player1current.frameData.hitBoxes)
            {
                if (player1current.currentFrame >= hitboxGroup.active && player1current.currentFrame < hitboxGroup.active + hitboxGroup.activeFor) 
                {
                    player1Hitboxes.Add(hitboxGroup);
                }
            }
            foreach (var hitboxGroup in player2current.frameData.hitBoxes)
            {
                if (player2current.currentFrame >= hitboxGroup.active && player2current.currentFrame < hitboxGroup.active + hitboxGroup.activeFor)
                {
                    player2Hitboxes.Add(hitboxGroup);
                }
            }

            #endregion
        }
        public void init()
        {
            player1Object = Instantiate(genericCharacter);
            player2Object = Instantiate(genericCharacter);
            player1Character = Character.loadByName("Bart");
            player2Character = Character.loadByName("Bart");
            player1current = player1Character.Animations["idle"].Copy();
            player2current = player2Character.Animations["idle"].Copy();
        }
    }
}
