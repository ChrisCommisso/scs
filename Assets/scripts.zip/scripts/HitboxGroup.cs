﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;

namespace Assets.scripts
{
    [Serializable]
    public class HitboxGroup
    {
        public int active;
        public int activeFor;
        public Vector3 velocity;
        public List<Rectangle> boxes;
    }
}
