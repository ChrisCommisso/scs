﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;

namespace Assets.scripts
{
    public class MoveData
    {
        public int animLength;//60
        public int hitstopFrames;
        public int throwInvulStartup;
        public int hitInvulStartup;
        public int armorStartup;
        public int throwInvulEnd;
        public int hitInvulEnd;
        public int armorEnd;
        public bool airOk;
        public bool groundOk;
        public string onHitAnim;
        public string[] requireResource;
        public string naturalEndAnim;
        public string[] input;//"2","3","6+B"
        public string[] actions;
        public string[] canCancelTo;//"animid-frame" eg. "dash-5" can cancel to dash by frame 5 if the string contaqins a '~' at the front character it will require a hit to cancel as well
        public KaraFrame[] karaKeyFrames;
        public HitboxGroup[] hitBoxes;
        public List<Rectangle>[] hurtBoxes;//100 pixels per unit for rect sizing, hitboxes will auto scale .01 unit per pixel
    }
}
