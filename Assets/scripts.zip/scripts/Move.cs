﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;

namespace Assets.scripts
{
    public class Move
    {
        public int currentFrame;
        public List<Sprite> frames;
        public MoveData frameData;
        public Move Copy() 
        {
            Move m = new Move();
            m.currentFrame = 0;
            m.frameData = this.frameData;
            m.frames = this.frames;
            return m;
        }
    }
}
